package enums;

public enum ClientType {
	PHYSICAL, LEGAL
}
