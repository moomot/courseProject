package enums;

public enum DebitorType {
	LONG, SHORT
}
