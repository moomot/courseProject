package enums;

public enum KreditType {
	LONG, SHORT
}
